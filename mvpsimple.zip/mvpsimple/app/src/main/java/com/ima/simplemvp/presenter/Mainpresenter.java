package com.ima.simplemvp.presenter;

public interface Mainpresenter {
    void Login (Double username,Double password);
}
